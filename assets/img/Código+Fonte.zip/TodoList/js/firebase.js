// Your web app's Firebase configuration
var firebaseConfig = {
  apiKey: "AIzaSyCvEv7AropwWlIEC-w5c3JgprOPxjA8-kM",
  authDomain: "todolist-84473.firebaseapp.com",
  databaseURL: "https://todolist-84473.firebaseio.com",
  projectId: "todolist-84473",
  storageBucket: "todolist-84473.appspot.com",
  messagingSenderId: "1009074245486",
  appId: "1:1009074245486:web:f573ce9d33c653b28ebb7f"
};
// Initialize Firebase
firebase.initializeApp(firebaseConfig);