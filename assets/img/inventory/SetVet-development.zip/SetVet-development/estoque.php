<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SetVet</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js" integrity="sha384-7+zCNj/IqJ95wo16oMtfsKbZ9ccEh31eOz1HGyDuCQ6wgnyJNSYdrPa03rtR1zdB" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js" integrity="sha384-QJHtvGhmr9XOIpI6YVutG+2QOK9T+ZnN4kzFN1RtK3zEFEIsxhlmWl5/YESvpZ13" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="css/estoque.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Anton&family=Archivo+Narrow:wght@700&display=swap" rel="stylesheet">
    <link rel="shortcut icon" href="./assets/img/home/header-logo.png" type="image/x-icon">
</head>
<body>
    <header class="d-flex justify-content-between align-items-center">
        <div class="d-flex align-items-center">
            <figure>
                <img src="./assets/img/home/header-logo.png" alt="">
            </figure>
            <h1 class="ms-2 mb-0">
                SETVET
            </h1>
        </div>
        <div class="buttons-home d-flex justify-content-between align-items-center">
            <a href="index.html">Home</a>
            <a href="calendar.html">Agenda</a>
            <a href="clients.html">Clientes</a>
            <a href="vaccine.html">Vacinas</a>
            <a href="services.html">Serviços</a>
            <a href="financial.html">Financeiro</a>
            <a href="estoque.php">Produtos</a>
            <a href="about.html">Sobre</a>
        </div>
        <div class="signup me-4">
            <a href="">Entrar</a>
        </div>
    </header>
    <main class="d-flex justify-content-center align-items-center">
        <div class="w-100 h-100 d-flex justify-content-center align-items-center">
            <div class="table d-flex">
                <div class="left-infos d-flex flex-column justify-content-around align-items-center">
                    Visão geral
                    <div class="products d-flex flex-column justify-content-center align-items-start w-50">
                        Produtos:
                        <span>
                            528
                        </span>
                    </div>
                    <div class="sold d-flex flex-column justify-content-center align-items-start w-50">
                        Vendidos:
                        <span>
                            30
                        </span>
                    </div>
                    <div class="best-seller d-flex flex-column justify-content-center align-items-start w-50">
                        Mais vendido:
                        <span>
                            Bolinha
                        </span>
                    </div>
                    <button>
                        Adicionar produto
                    </button>
                </div>
                <div class="sub-table d-flex flex-column align-items-end">
                    <div class="search-order d-flex align-items-end">
                        <div class="title d-flex mb-2 ms-4">
                            Estoque de Produtos
                        </div>
                        <div class="orderby d-flex align-items-center mb-2 ms-4">
                            Ordenar por
                            <figure class="ms-2">
                                <img src="./assets/img/inventory/down-arrow.png" class="w-100 h-100">
                            </figure>
                        </div>
                        <div class="search d-flex mb-2">
                            <figure class="me-2">
                                <img src="./assets/img/inventory/magnifier.png" class="w-100 h-100">
                            </figure>
                            <form id="frm_pesq_prod" name="frm_pesq_prod" method="POST" action="#">
                                <input type="text" id="Pesquisa_Prod" name="Pesquisa_Prod" placeholder="Pesquisar produtos">     <!-- Pesquisa dos Produtos -->
                                <input type="submit" id="Consultar" name="Consultar" value="Consultar"><br>
                            </form>
                        </div>
                    </div>
                    <div class="inf-table">
                        <div class="table-titles pt-3 mb-2">
                            <div class="ps-4">
                                Código do Produto
                            </div>
                            <div class="ps-4">
                                Produto
                            </div>
                            <div class="ps-4">
                                Data
                            </div>
                            <div class="ps-4">
                                Valor
                            </div>
                            <div class="ps-4">
                                Quantidade
                            </div>
                        </div>
                        <div class="table-items d-flex flex-column">
<?php
    
// =================================================== O que já tava ===============================
include "connect.php";
// if($_REQUEST['action'] == 'pesq')
// {
// $pesquisa_prod = "";
// $i = 0 ;
// $contagem_prod = array();
// if ($_POST['pesquisa_prod'] != null)
// {
    // if(!empty($_POST) && $_SERVER['REQUEST_METHOD'] == '_POST'){
    //     $pesquisa_prod = $_POST['pesquisa_prod'];
    // }
    // $_SESSION['pesquisa_prod'] == $_POST['Pesquisa_Prod'];
    // if (!$_POST['submit'])
    // {
// if( isset($_POST['Pesquisa_Prod']) )  { 
// $pesquisa_prod = $_POST['Pesquisa_Prod'];
        
// if ($pesquisa_prod == "" || $pesquisa_prod == NULL)
// {
    try
    {
        $Comando=$conexao->prepare("SELECT * FROM produtos Order By Cod_Prod");
       
        if ($Comando->execute())
       {
           while ($registro = $Comando->fetch(PDO::FETCH_OBJ))
           {
               
               // echo <div class="d-flex"><div class="w-25 d-flex justify-content-center align-items-center">. $registro->Nome_Prod .</div>
               // <div class="w-25 d-flex justify-content-center align-items-center">. $registro->Cod_Prod .</div>
               // <div class="w-25 d-flex justify-content-center align-items-center">. $registro->Quantidade .</div>
               // <div class="w-25 d-flex justify-content-center align-items-center">'R$ '. $registro->Valor .</div></div>
   
               // echo '<center>';
               // echo 'Código do Produto:'               . $registro->Cod_Prod . '<br>';
               // echo 'Nome do Produto: '                . $registro->Nome_Prod . '<br>';
               // echo 'Quantidade: '                     . $registro->Quantidade . '<br>';
               // echo 'Valor: '                          . $registro->Valor . '<br>';
               // echo '<p>';
               // echo '<hr>';
    ?>
    <div class="item w-100 py-2"><div class="cod ps-4"><?php echo $registro->Cod_Prod   ?></div>
    <div class="product ps-4"><?php echo $registro->Nome_Prod  ?></div>
    <div class="date ps-4"><?php echo date('d/m/Y H:i:s', strtotime($registro->Data))  ?></div>
    <div class="price ps-4"><?php echo 'R$ ' . $registro->Valor  ?></div>
    <div class="amount ps-4"><span><?php echo $registro->Quantidade   ?></span>/1000</div>
    <?php
               // $contagem_prod[] = $i;
               // $i++;
    ?>
    <figure><img src="./assets/img/inventory/edit.png" class="w-100 h-100">
    <a href="estoque.php?id=<?php echo $registro->Cod_Prod   ?>"></figure><figure><img src="./assets/img/inventory/delete.png" class="w-100 h-100"></a></figure></div> 

    <?php
    
        }
    
    }
    
    else
    {
        echo "<script> alert('não foi possível completar a consulta!')</script>";
    }
        
    }
    catch (PDOException $Erro)
{
	echo 'Erro, entrar em contato com equipe TI' .$Erro->getMessage();
}
//}
// else
// {
//     try
//     {
//         $Comando=$conexao->prepare("SELECT * FROM produtos Order By Cod_Prod WHERE Nome_Prod = ?");
//         $Comando-> bindParam(1, $pesquisa_prod);
        
       
       
//         if ($Comando->execute())
//        {
//            while ($registro = $Comando->fetch(PDO::FETCH_OBJ))
//            {
               
//                // echo <div class="d-flex"><div class="w-25 d-flex justify-content-center align-items-center">. $registro->Nome_Prod .</div>
//                // <div class="w-25 d-flex justify-content-center align-items-center">. $registro->Cod_Prod .</div>
//                // <div class="w-25 d-flex justify-content-center align-items-center">. $registro->Quantidade .</div>
//                // <div class="w-25 d-flex justify-content-center align-items-center">'R$ '. $registro->Valor .</div></div>
   
//                // echo '<center>';
//                // echo 'Código do Produto:'               . $registro->Cod_Prod . '<br>';
//                // echo 'Nome do Produto: '                . $registro->Nome_Prod . '<br>';
//                // echo 'Quantidade: '                     . $registro->Quantidade . '<br>';
//                // echo 'Valor: '                          . $registro->Valor . '<br>';
//                // echo '<p>';
//                // echo '<hr>';
    /* ?>
    // <!-- <div class="item w-100 py-2"><div class="cod ps-4"><?php echo $registro->Cod_Prod   ?></div>
    // <div class="product ps-4"><?php echo $registro->Nome_Prod  ?></div>
    // <div class="date ps-4"><?php echo date('d/m/Y H:i:s', strtotime($registro->Data))  ?></div>
    // <div class="price ps-4"><?php echo 'R$ ' . $registro->Valor  ?></div>
    // <div class="amount ps-4"><span><?php echo $registro->Quantidade   ?></span>/1000</div> -->
    // <?php */
//                // $contagem_prod[] = $i;
//                // $i++;
     /* ?>
//    <!--  <figure><img src="./assets/img/inventory/edit.png" class="w-100 h-100">
//     <a href="estoque.php?id=<?php echo $registro->Cod_Prod   ?>"></figure><figure><img src="./assets/img/inventory/delete.png" class="w-100 h-100"></a></figure></div> 
-->
//     <?php */
    
//         }
    
//     }
    
//     else
//     {
//         echo "<script> alert('não foi possível completar a consulta!')</script>";
//     }
        
//     }
//     catch (PDOException $Erro)
// {
// 	echo 'Erro, entrar em contato com equipe TI' .$Erro->getMessage();
// }
// }
// fechamento IF =====
// aqui é o fechamento
                        
?>

                    <!-- 
                                <div class="item w-100 py-2"><div class="cod ps-4">45635</div>
                            <div class="product ps-4">Bolinha</div>
                            <div class="date ps-4">02/04/2021</div>
                            <div class="price ps-4">R$35,00</div><div class="amount ps-4"><span>300/</span>500</div>
                            <figure><img src="./assets/img/inventory/edit.png" class="w-100 h-100">
                        </figure><figure><img src="./assets/img/inventory/delete.png" class="w-100 h-100"></figure></div> 

                    -->
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
    </main>
    <footer>

    </footer>
    <!-- ==================================    TESTEEE    ================================= -->
    <?php

include "connect.php";


// echo $id;

// if(isset($_GET['id']) == 1){

//  testeOnclick();
// }


// $CodForn = $_POST["CodForn"];

// $CodForn = filter_var($CodForn, FILTER_SANITIZE_NUMBER_INT);
if (isset($_GET['id']) == false)
{

}
else
{
    $id = $_GET["id"];
try
    {
    $Comando=$conexao->prepare("DELETE FROM produtos WHERE Cod_Prod = ? ");
    // $Comando=$conexao->prepare("DELETE FROM fornecedores WHERE CNPJ = ? AND Nome_Emp = ? AND Endereco = ? AND CEP = ? AND Telefone = ? AND Email = ? AND CodProduto = ?");  // Corrigir aqui para apenas 1 campo
    /* $Comando=$conexao->prepare("DELETE FROM fornecedores WHERE (CNPJ,Nome_Emp,Endereco,CEP,Telefone,Email,CodProduto) values (?,?,?,?,?,?,?)"); */ 
    $Comando->bindParam(1, $id);

    $Comando->execute();



    if($Comando->rowCount() > 0)
    {
        $Retorno_JSON = "Exclusão efetuada com sucesso!";
        ?>
        <meta http-equiv="refresh" content="0; URL='http://localhost/3_ano/Set_Dev/SetVet-development/estoque.php'"/>  <!-- content = tempo para recarregar a pag -->
        <?php
    }
    else
    {
        $Retorno_JSON = "Erro: Não foi possível excluir, Tente novamente!";
    }
    }
catch (PDOException $erro)
    {
        $Retorno_JSON = "deu erro, favor falar com Info " . $erro->getMessage();
    }
        echo $Retorno_JSON;
        // echo "<script type='javascript'>alert('Email enviado com Sucesso!');";
        // echo "javascript:window.location='index.php';</script>";
        
}
        
?>
<!-- <input type="button" class='btn' value="Voltar" onClick="history.go(-1)"> -->
<!-- <meta http-equiv="refresh" content="5; URL='http://localhost/3_ano/Set_Dev/SetVet-development/estoque.php'"/> -->
</body>
</html>
<script>
        // ajax consulta
        $(document).ready(function(){

            $('#Consultar').click(function() {
                var dados = $('#frm_pesq_prod').serialize();

                $.ajax({
                    method: 'POST',
                    url: 'estoque.php',
                    data: dados,

                })
                // return false;
            });
        })
</script>