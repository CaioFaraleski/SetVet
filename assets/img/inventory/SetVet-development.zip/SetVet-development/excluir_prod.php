<?php

include "connect.php";

$id = $_GET["id"];
// echo $id;

// if(isset($_GET['id']) == 1){

//  testeOnclick();
// }


// $CodForn = $_POST["CodForn"];

// $CodForn = filter_var($CodForn, FILTER_SANITIZE_NUMBER_INT);

try
    {
    $Comando=$conexao->prepare("DELETE FROM produtos WHERE Cod_Prod = ? ");
    // $Comando=$conexao->prepare("DELETE FROM fornecedores WHERE CNPJ = ? AND Nome_Emp = ? AND Endereco = ? AND CEP = ? AND Telefone = ? AND Email = ? AND CodProduto = ?");  // Corrigir aqui para apenas 1 campo
    /* $Comando=$conexao->prepare("DELETE FROM fornecedores WHERE (CNPJ,Nome_Emp,Endereco,CEP,Telefone,Email,CodProduto) values (?,?,?,?,?,?,?)"); */ 
    $Comando->bindParam(1, $id);

    $Comando->execute();

    if($Comando->rowCount() > 0)
    {
        $Retorno_JSON = "Exclusão efetuada com sucesso!";
    }
    else
    {
        $Retorno_JSON = "Erro: Não foi possível excluir, Tente novamente!";
    }
    }
catch (PDOException $erro)
    {
        $Retorno_JSON = "deu erro, favor falar com Info " . $erro->getMessage();
    }
        echo $Retorno_JSON;
        // echo "<script type='javascript'>alert('Email enviado com Sucesso!');";
        // echo "javascript:window.location='index.php';</script>";
        
        
?>
<!-- <input type="button" class='btn' value="Voltar" onClick="history.go(-1)"> -->
<!-- <meta http-equiv="refresh" content="5; URL='http://localhost/3_ano/Set_Dev/SetVet-development/estoque.php'"/> -->
