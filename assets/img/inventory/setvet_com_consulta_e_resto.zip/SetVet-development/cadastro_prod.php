<?php

require "connect.php";

$nomeprod = $_POST["Nome_Prod"];
$quantidade = $_POST["Quantidade"];
$valor = $_POST["Valor"];   // só funciona com .     tipo 3.20


$nomeprod = filter_var($nomeprod, FILTER_SANITIZE_STRING);
$quantidade = filter_var($quantidade, FILTER_SANITIZE_NUMBER_INT);
// $valor = filter_var($valor, FILTER_SANITIZE_NUMBER_FLOAT);

try
    {
    $Comando=$conexao->prepare("INSERT INTO produtos (Nome_Prod, Quantidade, Valor) VALUES (?, ?, ?)");
                $Comando->bindParam(1,$nomeprod);
                $Comando->bindParam(2,$quantidade);
                $Comando->bindParam(3,$valor);

    $Comando->execute();

    if($Comando->rowCount() > 0)
    {
        $Retorno_JSON = "Cadastrado Efetuado com Sucesso!!!";
    }
    else
    {
        $Retorno_JSON = "Erro no Cadastro Tente Novamente";
    }
    }
catch (PDOException $erro)
    {
        $Retorno_JSON = "deu erro, favor falar com Info " . $erro->getMessage();
    }
        echo $Retorno_JSON;



    // require "connect.php"; // arquivo de conexão

    // // if(isset($_POST['Cod_Prod'])) {$codprod=($_POST['Cod_Prod']);}
    // if(isset($_POST['Nome_Prod'])) {$nomeprod=$_POST['Nome_Prod'];}
    // if(isset($_POST['Quantidade'])) {$quantidade=$_POST['Quantidade'];}
    // if(isset($_POST['Valor'])) {$valor=$_POST['Valor'];}
    
    //     require "filtro.php"; // arquivo de filtragem de dados e execução
    //     {
    //         try
    //         {
    //             $sql = $conexao->prepare("insert into produtos (Nome_Prod, Quantidade, Valor) values (?, ?, ?)");
    //             // $sql->bindParam(1,$codprod);
    //             $sql->bindParam(1,$nomeprod);
    //             $sql->bindParam(2,$quantidade);
    //             $sql->bindParam(3,$valor);
                
    //             $sql->execute();
                
    //             if ($sql->rowCount() >= 1)
    //             {
    //                 $retorno = "<h4>Valores registrados!</h4>";
    //             }

    //             else
    //             {
    //                 $retorno = "<h4>Favor realizar o processo novamente, erro na gravação</h4>";
    //             }
    //         }

    //         catch (PDOException $falha)
    //         {
    //             $retorno = "<h4>Erro! Entrar em contato com a equipe de TI</h4>" . $falha->getMessage();
    //         }    

    //         echo $retorno;
    //     }
?>