<?php
$Bco = "setvet";
$Usuario = "root";
$Senha = "";        // usbw ou em branco    $senha = "usbw";    $senha = "";

try
{
    $conexao = new PDO("mysql:host=localhost; dbname=$Bco", "$Usuario", "$Senha");    
    $conexao->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);               
    $conexao->exec("set names utf8");
}
catch (PDOException $erro)
{
    echo "Erro na conexao, favor entrar em contato do TI " . $erro->getMessage();
}