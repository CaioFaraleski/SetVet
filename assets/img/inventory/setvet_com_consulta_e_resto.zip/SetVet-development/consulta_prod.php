<?php
if (!isset($_POST['Pesquisa_Prod'])) {
	header("Location: estoque.php");
	exit;
}
 
$pesquisa_prod = "%".trim($_POST['Pesquisa_Prod'])."%";
 
// $dbh = new PDO('mysql:host=127.0.0.1;dbname=canalti', 'root', 'root1234');
include "connect.php";
 
$Comando = $conexao->prepare('SELECT * FROM `produtos` WHERE `Nome_Prod` LIKE :Nome_Prod');
$Comando->bindParam(':Nome_Prod', $pesquisa_prod, PDO::PARAM_STR);
$Comando->execute();
 
$registro = $Comando->fetchAll(PDO::FETCH_ASSOC);
?>
 
<!DOCTYPE html>
<html>
<head>
	<title>Resultado da busca</title>
</head>
<body>
<h2>Resultado da busca</h2>
<?php
if (count($resultados)) {
	foreach($resultados as $Resultado) {
?>
<label><?php echo $Resultado['id']; ?> - <?php echo $Resultado['nome']; ?></label> 
<br>
<?
} } else {
?>
<label>Não foram encontrados resultados pelo termo buscado.</label>
<?php
}
?>
</body>
</html>